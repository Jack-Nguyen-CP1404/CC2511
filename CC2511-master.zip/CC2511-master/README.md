# CC2511
Embedded system design
