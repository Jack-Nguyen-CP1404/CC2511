#include "Cpu.h"
#include "Events.h"
#include "Term1.h"
#include "Inhr1.h"
#include "ASerialLdd1.h"
#include "Direction1.h"
#include "BitIoLdd1.h"
#include "Direction2.h"
#include "BitIoLdd2.h"
#include "Direction3.h"
#include "BitIoLdd3.h"
#include "Mode0.h"
#include "BitIoLdd4.h"
#include "Mode1.h"
#include "BitIoLdd5.h"
#include "Mode2.h"
#include "BitIoLdd6.h"
#include "PWM1.h"
#include "PwmLdd1.h"
#include "TU1.h"
#include "PWM4.h"
#include "PwmLdd2.h"
#include "PWM2.h"
#include "PwmLdd3.h"
#include "TU2.h"
#include "PWM3.h"
#include "PwmLdd4.h"
#include "DECAY.h"
#include "BitIoLdd7.h"
#include "nENBL_internal_pull_down.h"
#include "BitIoLdd8.h"
#include "nFault.h"
#include "BitIoLdd9.h"
#include "nHome.h"
#include "BitIoLdd10.h"
#include "nSleep_internal_pull_down_question.h"
#include "BitIoLdd11.h"
#include "nReset_pull_down_question.h"
#include "BitIoLdd12.h"
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"

void draw_GUI(){

	//set the position
	Term1_MoveTo(1,1);
	//set the colour
	Term1_SetColor(clYellow, clBlack);
	Term1_SendStr("CC2511 Lab 7");

	Term1_MoveTo(1,3);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr("+--[ PWM Status ]--+");

    Term1_MoveTo(22,3);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr("+----------[ How to use ]----------+");

	//coloumn colour setting
	Term1_MoveTo(21,3);
	Term1_SetColor(clBlack, clBlack);
	Term1_SendStr(" ");

	Term1_MoveTo(22,4);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(22,5);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(22,6);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(22,7);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(22,8);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(22,9);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(22,10);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr("                                       ");


	Term1_MoveTo(1,4);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(1,5);
	Term1_SetColor(clBlack, clRed);
	Term1_SendStr(" ");

	Term1_MoveTo(1,6);
	Term1_SetColor(clBlack, clGreen);
	Term1_SendStr(" ");

	Term1_MoveTo(1,7);
	Term1_SetColor(clBlack, clBlue);
	Term1_SendStr(" ");

	Term1_MoveTo(1,8);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr("                    ");

	Term1_MoveTo(20,4);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(20,5);
	Term1_SetColor(clBlack, clRed);
	Term1_SendStr(" ");

	Term1_MoveTo(20,6);
	Term1_SetColor(clBlack, clGreen);
	Term1_SendStr(" ");

	Term1_MoveTo(20,7);
	Term1_SetColor(clBlack, clBlue);
	Term1_SendStr(" ");

	Term1_MoveTo(58,4);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(59,5);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(60,6);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(61,7);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(61,8);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");

	Term1_MoveTo(61,9);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");\

	Term1_MoveTo(61,10);
	Term1_SetColor(clBlack, clYellow);
	Term1_SendStr(" ");





	//end coloumn colour setting

	//colour label setting
	Term1_MoveTo(3,5);
	Term1_SetColor(clWhite, clRed);
	Term1_SendStr("Red:");

	Term1_MoveTo(3,6);
	Term1_SetColor(clBlack, clGreen);
	Term1_SendStr("Green:");

	Term1_MoveTo(3,7);
	Term1_SetColor(clWhite, clBlue);
	Term1_SendStr("Blue:");
	//end label setting

	Term1_MoveTo(23,6);
	Term1_SetColor(clWhite, clBlack);
	Term1_SendStr("> red n   Set the red pwm ratio to n");

	Term1_MoveTo(23,7);
	Term1_SetColor(clWhite, clBlack);
	Term1_SendStr("> green n   Set the red pwm ratio to n");

	Term1_MoveTo(23,8);
	Term1_SetColor(clWhite, clBlack);
	Term1_SendStr("> blue n   Set the red pwm ratio to n");

	Term1_MoveTo(23,9);
	Term1_SendStr("> off     turns the LEDs off        ");

	Term1_MoveTo(1,11);
	Term1_SendStr("Command Prompt:");
	Term1_MoveTo(1,12);
	Term1_SendStr("> ");
}

int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/
